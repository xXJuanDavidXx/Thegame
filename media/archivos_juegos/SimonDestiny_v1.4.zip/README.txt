Thank you for downloading Castlevania: Simon's Destiny!


--------DISCLAIMER------------

This is a free non profit fangame based on Konami's Castlevania Franchise. All trademarked characters belong to their respective owners. 

--------HOW TO INSTALL--------

* Download Gzdoom (Version 3.7.1 or newer) at https://zdoom.org/downloads
* Put Castlevania.ipk3 in the same folder of Gzdoom
* Open Gzdoom and select "Castlevania: Simon's Destiny" in the game window (Make sure video settings below the selection box are set on "Hardware (OpenGL)")
* Play!

--------REQUIRED KEYS---------

Movement Keys (Forward, Backward, Strafe Left, Strafe Right)
Primary Fire
Secondary Fire
Jump
Crouch
Use

Please enable "Always Autorun" from the player's menu


--------BUG REPORT, COMMENTS, QUESTIONS-------------

Want to report a bug? Write a comment about the game? Ask a question about something?

You can find the main development thread here!

https://forum.zdoom.org/viewtopic.php?f=19&t=57800

--------CREDITS--------------


[[  THINK YOU SHOULD BE IN THE CREDITS BUT ARE NOT LISTED? SEND ME A PRIVATE MESSAGE IN THE LINK POSTED ABOVE AND I'LL ADD YOU TO THIS README AND THE INGAME CREDITS  ]]

Fangame by Andrea Gori "Batandy"

Whip - Mike12, TerminusEst13, Captain J
Simon Sprites - Khefz
Sway- Nash
Simon Sprites - Khefz
Enemies - Vader, Finalizer, Horror Movie Guy, Tormentor667, Espi, Popsoap, Ghastly_dragon, Rolls, DoomJedi, Ringman
Props - ETTiNGRiNDER, Blox, Captain Toenail, Gez, Gothic, scalliano, cgman
Fonts - Boba Fonts, Jimmy, NeuralStunner
Textures - Zdoom Texture Thread, osjclatchford, Enjay, empessah, GothicDM Team 
Zscript - Zombosis

Music

-Ogg Loops by Felgerian-

Poison Mind - Yaworski Remix Studio

https://www.youtube.com/channel/UCKVxozPUPuRX4QqyhmB1P2w

Level 1 - Dracula Battle I - Perfect Selection

Konami Album

Level 2 - JILost

https://soundcloud.com/jesse-ingram/jilost-castlevania-stalker

Level 3 - devilbelmont

https://www.youtube.com/watch?v=oPBE0TkEpBg

Level 4 - Castlevania The Arcade

Level 5 - Dinnick the 3rd

https://www.youtube.com/watch?v=PcZj7q0phq4

Level 6 - The Lost Vampire Killer (Album) composition arranged by nijeil

Den - Dracula Battle II - Perfect Selection

Title Screen - Dracula New Classic - Perfect Selection

Dracula Battle:

Phase 1 - Matthew Beckham
https://www.youtube.com/watch?v=TxAqqxeXXTY

Phase 2 - Castlevania The Arcade

Phase 3 - Friedrich Habetler

https://www.youtube.com/watch?v=KPXjixmyOK4